qa_automation_framework
=======================

This repository provides a starter layout for API QA automation.

Layout
------
- `config/` - configuration helpers and environment-specific settings
- `core/` - core clients, authentication helpers, request wrappers
- `utils/` - utility helpers, data factories
- `tests/` - test suites organized by area
  - `auth/`, `crud/`, `validation/`, `errors/`, `perf/`, `edge/`
- `reports/` - output test/report artifacts

Quick start
-----------
1. Create a virtual environment and activate it (PowerShell):

```powershell
Set-Location -Path "C:\Users\JahnaviMallela\Desktop\api_auto\qa_automation_framework"
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

2. Configure environment variables using `.env.example` as a template.
3. Run tests:

```powershell
pytest
pytest --html=reports/report.html
```

Contributing
------------
Add tests under the appropriate `tests/` subdirectory and keep fixtures in `conftest.py`.
