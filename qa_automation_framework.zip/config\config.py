from dotenv import load_dotenv
import os
load_dotenv()
class Config:
    JSONPLACEHOLDER = "https://jsonplaceholder.typicode.com"
    REQRES = "https://reqres.in/api"
    HTTPBIN = "https://httpbin.org"
    GOREST = "https://gorest.co.in/public/v2"
    TIMEOUT = 10
    GOREST_TOKEN = os.getenv("GOREST_TOKEN", "")


# export an instance for easy imports
config = Config()
