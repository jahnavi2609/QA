import os
import pytest

from config.config import config
from core.api_client import APIClient


@pytest.fixture(scope="session")
def jsonplaceholder_client():
    return APIClient(config.JSONPLACEHOLDER)


@pytest.fixture(scope="session")
def reqres_client():
    return APIClient(config.REQRES)


@pytest.fixture(scope="session")
def httpbin_client():
    # use a slightly larger timeout for httpbin to accommodate delay endpoints in perf tests
    return APIClient(config.HTTPBIN, timeout=20)


@pytest.fixture(scope="session")
def gorest_client():
    headers = {"Authorization": f"Bearer {config.GOREST_TOKEN}"} if config.GOREST_TOKEN else {}
    return APIClient(config.GOREST, headers=headers)


@pytest.fixture
def anyio_backend():
    return "asyncio"


@pytest.fixture
def sample_payload():
    return {"name": "test", "value": 123}
