import time
import requests
from typing import Any, Dict, Optional
from .logger import get_logger
from config.config import config

logger = get_logger("api_client")


class APIClient:
    def __init__(self, base_url: str, headers: Optional[Dict[str, str]] = None, timeout: Optional[int] = None):
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()
        self.default_headers = headers or {}
        self.timeout = timeout or config.TIMEOUT

    def _prepare(self, path: str, headers: Optional[Dict[str, str]] = None):
        url = path if path.startswith("http") else f"{self.base_url}/{path.lstrip('/') }"
        hdrs = dict(self.default_headers)
        if headers:
            hdrs.update(headers)
        return url, hdrs

    def _request(self, method: str, path: str, **kwargs) -> requests.Response:
        url, hdrs = self._prepare(path, kwargs.pop("headers", None))
        start = time.time()
        logger.debug("%s %s headers=%s kwargs=%s", method.upper(), url, hdrs, {k: v for k, v in kwargs.items() if k != 'json'})
        r = self.session.request(method, url, headers=hdrs, timeout=self.timeout, **kwargs)
        elapsed = time.time() - start
        # attach elapsed_seconds for convenience
        setattr(r, "elapsed_seconds", elapsed)
        logger.debug("%s %s -> %s (%.3fs)", method.upper(), url, r.status_code, elapsed)
        # log truncated body
        try:
            text = r.text[:800]
        except Exception:
            text = "<no body>"
        logger.debug("response body (truncated): %s", text)
        return r

    def get(self, path: str, params: Optional[Dict[str, Any]] = None, **kwargs) -> requests.Response:
        return self._request("get", path, params=params, **kwargs)

    def post(self, path: str, json: Optional[Any] = None, data: Optional[Any] = None, **kwargs) -> requests.Response:
        return self._request("post", path, json=json, data=data, **kwargs)

    def put(self, path: str, json: Optional[Any] = None, **kwargs) -> requests.Response:
        return self._request("put", path, json=json, **kwargs)

    def patch(self, path: str, json: Optional[Any] = None, **kwargs) -> requests.Response:
        return self._request("patch", path, json=json, **kwargs)

    def delete(self, path: str, **kwargs) -> requests.Response:
        return self._request("delete", path, **kwargs)
