from pydantic import BaseModel, ValidationError
from typing import Type, Any


def validate_model(model: Type[BaseModel], payload: Any) -> None:
    try:
        model.parse_obj(payload)
    except ValidationError as exc:
        # re-raise with a clearer message for tests
        raise AssertionError(f"Schema validation failed: {exc}")


# Example model placeholder; real models should be created per endpoint
from pydantic import Field

class PostModel(BaseModel):
    id: int
    title: str
    body: str
    userId: int
