# Test Mapping (PDF TC ID -> test function)

Auth
----
- TC_AUTH_001 -> tests/auth/test_auth.py::test_auth_valid
- TC_AUTH_002 -> tests/auth/test_auth.py::test_auth_missing_password

CRUD
----
- TC_CRUD_001 -> tests/crud/test_crud.py::test_create_post_jsonplaceholder
- TC_CRUD_002 -> tests/crud/test_crud.py::test_create_user_gorest
- TC_CRUD_003 -> tests/crud/test_crud.py::test_read_post_jsonplaceholder

Validation
----------
- TC_VALID_001 -> tests/validation/test_validation.py::test_missing_required_field_gorest
- TC_VALID_002 -> tests/validation/test_validation.py::test_post_schema_jsonplaceholder

Errors
------
- TC_ERROR_001 -> tests/errors/test_errors.py::test_resource_not_found
- TC_ERROR_002 -> tests/errors/test_errors.py::test_method_not_allowed_httpbin

Perf
----
- TC_PERF_001 -> tests/perf/test_perf.py::test_response_time_get_single
- TC_PERF_002 -> tests/perf/test_perf.py::test_concurrent_requests_httpbin
- TC_PERF_004 -> tests/perf/test_perf.py::test_stress_small_batch

Edge
----
- TC_EDGE_001 -> tests/edge/test_edge.py::test_empty_request_body
- TC_EDGE_002 -> tests/edge/test_edge.py::test_maximum_string_lengths
- TC_EDGE_003 -> tests/edge/test_edge.py::test_unicode_special_chars


Notes
-----
- Tests that require an authenticated token (GoRest) are skipped by default; provide `GOREST_TOKEN` in `.env` to enable.
- Adapt test names to match the official PDF IDs if you prefer exact naming.
