import pytest


def test_dummy_auth(reqres_client):
    # sanity check that the reqres client fixture is available
    assert reqres_client is not None
