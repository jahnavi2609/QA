import pytest


def test_create_post_jsonplaceholder(jsonplaceholder_client):
    payload = {"title": "foo", "body": "bar", "userId": 1}
    r = jsonplaceholder_client.post("/posts", json=payload)
    assert r.status_code == 201
    body = r.json()
    assert body.get("id") is not None


@pytest.mark.skipif(True, reason="gorest tests require token; skip by default")
def test_create_user_gorest(gorest_client):
    payload = {"name": "Auto Test", "email": "auto@example.com", "gender": "male", "status": "active"}
    r = gorest_client.post("/users", json=payload)
    assert r.status_code in (200, 201)
    body = r.json()
    assert "id" in body


def test_read_post_jsonplaceholder(jsonplaceholder_client):
    r = jsonplaceholder_client.get("/posts/1")
    assert r.status_code == 200
    body = r.json()
    assert body.get("id") == 1
