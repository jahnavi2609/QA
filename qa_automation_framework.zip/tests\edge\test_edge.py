from utils.data_factory import long_string, random_email


def test_empty_request_body(jsonplaceholder_client):
    r = jsonplaceholder_client.post("/posts", json={})
    # jsonplaceholder accepts and returns created object; we tolerate 201 or 400
    assert r.status_code in (201, 400)


def test_maximum_string_lengths(jsonplaceholder_client):
    payload = {"title": long_string(2000), "body": long_string(5000), "userId": 1}
    r = jsonplaceholder_client.post("/posts", json=payload)
    assert r.status_code in (201, 400)


def test_unicode_special_chars(jsonplaceholder_client):
    payload = {"title": "日本語テスト😊", "body": "Привет мир", "userId": 1}
    r = jsonplaceholder_client.post("/posts", json=payload)
    assert r.status_code in (201, 400)
