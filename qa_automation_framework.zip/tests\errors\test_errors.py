def test_resource_not_found(jsonplaceholder_client):
    r = jsonplaceholder_client.get("/posts/9999")
    # jsonplaceholder returns 404 for out of range
    assert r.status_code in (404, 400)


def test_method_not_allowed_httpbin(httpbin_client):
    r = httpbin_client.post("/get")
    assert r.status_code in (405, 404)


def test_invalid_url_path(jsonplaceholder_client):
    r = jsonplaceholder_client.get("/invalid_path_abc")
    assert r.status_code in (404, 400)
