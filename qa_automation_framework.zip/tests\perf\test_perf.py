import time
import concurrent.futures


def test_response_time_get_single(jsonplaceholder_client):
    r = jsonplaceholder_client.get("/posts/1")
    assert r.status_code == 200
    assert getattr(r, "elapsed_seconds", 999) < 1


def test_concurrent_requests_httpbin(httpbin_client):
    # send 5 concurrent requests to /delay/1 (keeps it small for safety)
    url = "/delay/1"
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:
        futures = [ex.submit(httpbin_client.get, url) for _ in range(5)]
        results = [f.result() for f in futures]
    assert all(r.status_code == 200 for r in results)


def test_stress_small_batch(httpbin_client):
    # small stress to avoid abuse: 20 quick requests
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as ex:
        futures = [ex.submit(httpbin_client.get, "/get") for _ in range(20)]
        results = [f.result() for f in futures]
    assert all(r.status_code == 200 for r in results)
