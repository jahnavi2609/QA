from core.schema_validator import PostModel, validate_model


def test_post_schema_jsonplaceholder(jsonplaceholder_client):
    r = jsonplaceholder_client.get("/posts/1")
    assert r.status_code == 200
    body = r.json()
    validate_model(PostModel, body)


def test_missing_required_field_gorest(gorest_client):
    # Example: missing required field should return 422 or 400
    payload = {"name": ""}
    r = gorest_client.post("/users", json=payload)
    assert r.status_code in (400, 422, 401, 403)
