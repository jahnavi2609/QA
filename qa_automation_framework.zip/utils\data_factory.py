import random
import string
import time


def random_email(prefix: str = "user") -> str:
    ts = int(time.time() * 1000) % 100000
    return f"{prefix}{ts}@example.com"


def long_string(n: int) -> str:
    return ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(n))


def unique_name(prefix: str = "name") -> str:
    return f"{prefix}-{int(time.time())}-{random.randint(100,999)}"
